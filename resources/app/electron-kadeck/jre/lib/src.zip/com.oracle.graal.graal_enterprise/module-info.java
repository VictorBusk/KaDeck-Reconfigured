module com.oracle.graal.graal_enterprise {
    requires jdk.internal.vm.compiler;
    requires org.graalvm.truffle;
}
